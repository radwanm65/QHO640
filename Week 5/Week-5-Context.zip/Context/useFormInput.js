import React from 'react';

function useFormInput(defaultValue) {
    const [value,setValue] = React.useState(defaultValue);

    function handleChange(e) {
        setValue(e.target.value);
    }

    return {
        value, handleChange
    }
}

export default useFormInput;