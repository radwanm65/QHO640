import React from 'react';  // Import React library
import Nested2 from './Nested2';  // Import the Nested2 component

function Nested1() {
    const [name, setName] = React.useState("");  // Declare a state variable 'name' with initial value as an empty string

    return (
        <div>
            {/* Input field to enter the name */}
            <input id='name' />
            {/* Button to update the state 'name' with the value from the input field */}
            <input type='button' onClick={updateState} value='Go!' />
            {/* Pass the 'name' state as a prop to the Nested2 component */}
            <Nested2 name={name} />
        </div>
    );

    // Function to update the state 'name' with the value from the input field
    function updateState() {
        setName(document.getElementById('name').value);
    }
}

export default Nested1;  // Export the Nested1 component as the default export
