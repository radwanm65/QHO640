import React from 'react';  // Import React library
import Nested3 from './Nested3';  // Import the Nested3 component

function Nested2({name}) {
    return (
        <>
            {/* Display a greeting message using the 'name' prop */}
            <h1>Hello {name}!</h1>
            {/* Pass the 'name' prop to the Nested3 component */}
            <Nested3 name={name} />
        </>
    );
}

export default Nested2;  // Export the Nested2 component as the default export
