import React from 'react';
import useFormInput from './useFormInput';
    
function CustomHookComponent() {
    
    const ufiName = useFormInput("No name");
    const ufiCourse = useFormInput("No course");

    return (
        <div>
        Name:<br />
        <input id='name' onChange={ufiName.handleChange} /><br />
        Course: <br />
        <input id='course' onChange={ufiCourse.handleChange} /><br />
        Name {ufiName.value} course {ufiCourse.value} <br />
        </div>
    );
}

export default CustomHookComponent; 