import React from 'react';  // Import React library

function Nested3({name}) {
    return (
        // Display a welcome message using the 'name' prop
        <p>Welcome {name} to the site!</p>
    );
}

export default Nested3;  // Export the Nested3 component as the default export
