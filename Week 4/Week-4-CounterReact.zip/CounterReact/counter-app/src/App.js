import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <h1>ABC</h1>
  );
}

export default App;
