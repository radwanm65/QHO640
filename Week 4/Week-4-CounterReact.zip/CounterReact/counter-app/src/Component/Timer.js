// Importing necessary libraries
import React, { useState, useEffect } from 'react';

// Defining a functional component
const Timer = () => {
  // Using the useState hook to create state variables
  const [seconds, setSeconds] = useState(0);

  // Using the useEffect hook to perform side effects
  useEffect(() => {
    // Function to update the timer
    const tick = () => {
      setSeconds(prevSeconds => prevSeconds + 1);
    };

    // Setting up an interval to call the tick function every second
    const interval = setInterval(tick, 1000);

    // Cleanup function to clear the interval when the component unmounts
    return () => clearInterval(interval);
  }, []); // Empty dependency array means this effect runs once when the component mounts

  // Rendering the component
  return (
    <div>
      <h1>Timer</h1>
      <p>Seconds: {seconds}</p>
    </div>
  );
};

// Exporting the component as the default export
export default Timer;
