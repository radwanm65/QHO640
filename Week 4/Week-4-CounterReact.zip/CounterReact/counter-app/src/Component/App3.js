import React from 'react';

let renderings = 0;

function App3() {

    renderings++;
    const [name, setName] = React.useState("");

    return(
        <div>
        <h1>Hello {name}!</h1>
        <p>Number of renderings: {renderings}</p>
        <p><input id='name' />
        <input type='button' value='Go!' onClick={updateState} />
        </p>
        </div>
    );

    function updateState() {
        setName(document.getElementById('name').value);
    }

}

export default App3;