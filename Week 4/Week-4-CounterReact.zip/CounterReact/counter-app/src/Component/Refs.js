// Importing necessary libraries
import React, { useRef } from 'react';

// Defining a functional component
const Refs = () => {
  // Using the useRef hook to create a ref
  const inputEl = useRef(null);

  // Function to handle button click and focus the input
  const onButtonClick = () => {
    // Accessing the DOM node using the ref and calling the focus method
    inputEl.current.focus();
  };

  // Rendering the component
  return (
    <div>
      <input ref={inputEl} type="text" />
      <button onClick={onButtonClick}>Focus the input</button>
    </div>
  );
};

// Exporting the component as the default export
export default Refs;
