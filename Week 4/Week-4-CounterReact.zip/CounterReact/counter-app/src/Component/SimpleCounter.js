// Importing necessary libraries
import React, { useState } from 'react';

// Defining a functional component
const SimpleCounter = () => {
  // Using the useState hook to create state variables
  const [count, setCount] = useState(0); // 1,2 3 45

  // Function to handle button click and update the count
  const handleIncrement = () => {
    setCount(count + 1);
  };

  // Function to handle button click and reset the count
  const handleReset = () => {
    setCount(0);
  };

  // Rendering the component
  return (
    <div>
      <h1>Simple Counter</h1>
      <p>Count: {count}</p>
      <button onClick={handleIncrement}>Increment</button>
      <button onClick={handleReset}>Reset</button>
    </div>
  );
};

// Exporting the component as the default export
export default SimpleCounter;
