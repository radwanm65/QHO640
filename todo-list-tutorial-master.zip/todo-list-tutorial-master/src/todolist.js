const todos = [
    {
      id: "1",
      text: "Complete Android Assessment",
      created: "Jan 22 2024 07:02:0",
      completed: false,
    },
    {
      id: "2",
      text: "Organise Social Event",
      created: "Jan 23 2024 07:03:0",
      completed: true,
    },
    {
        id: "3",
        text: "Todo list Completed",
        created: "Jan 23 2024 07:03:0",
        completed: true,
      },
  ];
  
  export default todos;