import "./main.css";
import img1 from "../assets/top-left-elips.png";
import img2 from "../assets/bottom-right-elips.png";
import todos from "./todolist";
import Todo from "./todo";

const view = `
  <img
    src="${img1}"
    id="background-left"
    alt="background"
  />
  <img
    src="${img2}"
    id="background-right"
    alt="background"
  />
  <div class="wrapper">
    <div class="todolist">
      <h1>STUDENT TO DO LIST</h1>
      <form id="todoForm">
        <input type="text" id="todoInput" placeholder="What do you need to do today...." required />
        <button type="submit">Add Todo</button>
      </form>
      <div class="list"></div>
      <!-- /.list -->
    </div>
    <!-- /.todolist -->
  </div>
  <!-- /.wrapper -->
`;

function render(todosList) {
    console.log('ready');
    document.getElementById('app').innerHTML = view;

    // Create a new array 'tds' containing a copy of the todos list
    const tds = [...todosList];

    // Create a function which runs when the "close" span on each todo item is clicked
    const handleCloseClick = (e) => {
        // Filter out the item to be removed
        render(tds.filter((item) => e.target.id.substr(5) != item.id));
    };

    // Place 'view' inside your 'app' div
    document.querySelector(".list").innerHTML = tds.map((item) => Todo(item.text, item.id)).join(" ");

    // Setup event handlers on each 'X' close button
    document.querySelectorAll(".close").forEach((e) => e.addEventListener("click", handleCloseClick));

    // Ensure the form and input are available in the DOM
    const form = document.getElementById('todoForm');
    const input = document.getElementById('todoInput');

    // Handle adding new todos
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const newTodo = {
            id: (tds.length + 1).toString(),
            text: input.value,
            created: new Date().toString(),
            completed: false,
        };
        tds.push(newTodo);
        render(tds);
    });
}

// Modify your DOMContentLoaded to call render() via bind()
window.addEventListener("DOMContentLoaded", render.bind(this, todos));
