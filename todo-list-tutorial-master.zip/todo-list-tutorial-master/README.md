# A To Do List Tutorial 

Simple! Complete the to do list

## To get started 

- Clone this repository
- `npm install` to install the dependencies 
- `npm run start`

- Complete the Todolist